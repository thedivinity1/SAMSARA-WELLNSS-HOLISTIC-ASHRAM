'use client';
import React from 'react';

export const ClosingReflection = () => {
  return (
    <section className="h-[50vh] flex flex-col items-center justify-center bg-stone-50 text-center px-6">
      <blockquote className="font-serif text-3xl md:text-4xl text-stone-800 max-w-3xl leading-relaxed mb-8">
        "You are not a drop in the ocean. You are the entire ocean in a drop."
      </blockquote>
      <cite className="text-stone-500 not-italic uppercase tracking-widest text-xs">— Rumi</cite>
    </section>
  );
};
