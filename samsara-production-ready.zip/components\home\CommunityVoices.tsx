'use client';
import React from 'react';

const testimonials = [
  { quote: "Samsara isn't just a place. It's a remembering.", author: "Elena R.", role: "Member since 2021" },
  { quote: "The transparency here changed how I view giving.", author: "Marcus T.", role: "Donor Partner" },
  { quote: "Deep, rigorous, and completely devoid of fluff.", author: "Sarah L.", role: "Retreat Participant" },
];

export const CommunityVoices = () => {
  return (
    <section className="py-32 bg-stone-100">
      <div className="container-wide">
        <h2 className="font-serif text-3xl text-center mb-16 text-stone-900">Voices from the Path</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {testimonials.map((t, idx) => (
            <div key={idx} className="flex flex-col items-center text-center space-y-6">
              <div className="text-4xl text-sage-300 font-serif">"</div>
              <p className="font-serif text-xl text-stone-700 italic leading-relaxed max-w-xs">
                {t.quote}
              </p>
              <div>
                <div className="font-semibold text-stone-900 text-sm">{t.author}</div>
                <div className="text-stone-500 text-xs uppercase tracking-wider">{t.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
