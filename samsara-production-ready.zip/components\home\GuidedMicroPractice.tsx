'use client';
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

export const GuidedMicroPractice = () => {
  const [active, setActive] = useState(false);

  return (
    <section className="py-32 bg-stone-50 flex flex-col items-center justify-center text-center px-6">
      <div className="max-w-2xl space-y-8">
        <h2 className="font-serif text-3xl text-stone-800">Pause for a moment.</h2>
        <p className="text-stone-500">Take a deep breath. Connect with the present.</p>
        
        <div className="relative flex items-center justify-center py-12">
          {/* Breathing Circle Animation */}
          <motion.div 
            className="w-48 h-48 rounded-full border border-sage-300 flex items-center justify-center relative cursor-pointer group"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
            onClick={() => setActive(!active)}
          >
             <div className="absolute inset-0 bg-sage-100/50 rounded-full blur-xl group-hover:bg-sage-200/50 transition-colors"></div>
             <span className="relative z-10 font-serif text-sage-800 italic">Breathe</span>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
