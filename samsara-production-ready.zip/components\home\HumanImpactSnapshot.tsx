'use client';
import React from 'react';
import { motion } from 'framer-motion';

export const HumanImpactSnapshot = () => {
  const stats = [
    { value: "12,500+", label: "Lives Touched" },
    { value: "45", label: "Community Programs" },
    { value: "$2.4M", label: "Funds Deployed" },
    { value: "100%", label: "Transparent Allocation" },
  ];

  return (
    <section className="py-20 bg-sage-900 text-sage-50">
      <div className="container-wide">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
          {stats.map((stat, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="space-y-2"
            >
              <div className="font-serif text-4xl md:text-5xl text-white">{stat.value}</div>
              <div className="text-sage-300 text-xs uppercase tracking-widest">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
