'use client';
import React from 'react';
import { motion } from 'framer-motion';

export const InteractiveTimeline = () => {
  return (
    <section className="py-32 bg-sage-50 overflow-hidden">
      <div className="container-wide text-center mb-16">
        <h2 className="font-serif text-4xl text-stone-900 mb-4">Your Journey</h2>
        <p className="text-stone-500">From seeker to guide. A lifelong path.</p>
      </div>
      
      <div className="relative max-w-5xl mx-auto">
        <div className="absolute top-1/2 left-0 right-0 h-px bg-sage-200 -translate-y-1/2 hidden md:block"></div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative z-10">
          {['Curiosity', 'Immersion', 'Integration', 'Service'].map((step, idx) => (
            <div key={idx} className="text-center group">
              <motion.div 
                whileHover={{ scale: 1.1 }}
                className="w-12 h-12 bg-white border-2 border-sage-300 rounded-full mx-auto mb-6 flex items-center justify-center font-serif text-sage-800 relative z-20"
              >
                {idx + 1}
              </motion.div>
              <h3 className="font-serif text-lg text-stone-800 mb-2">{step}</h3>
              <p className="text-xs text-stone-500 max-w-[150px] mx-auto">
                Step {idx + 1} description placeholder text.
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
