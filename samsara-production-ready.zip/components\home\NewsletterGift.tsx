'use client';
import React from 'react';

export const NewsletterGift = () => {
  return (
    <section className="py-24 bg-white border-t border-stone-100">
      <div className="container-wide grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
        <div>
           <h2 className="font-serif text-4xl text-stone-900 mb-6">A weekly gift, not an email.</h2>
           <p className="text-stone-600 mb-8">
             Join 45,000+ seekers receiving "The Sunday Stillness"—a curated collection of 
             teachings, silence, and poetry. No marketing, just depth.
           </p>
           <form className="flex gap-0">
             <input 
               type="email" 
               placeholder="Enter your email" 
               className="flex-grow bg-stone-50 border border-stone-200 p-4 focus:outline-none focus:border-sage-400"
             />
             <button className="bg-stone-900 text-white px-8 hover:bg-stone-800 transition-colors">
               Receive
             </button>
           </form>
        </div>
        <div className="bg-stone-100 h-64 md:h-full rounded-sm flex items-center justify-center text-stone-400 italic font-serif">
          "The most peaceful email in my inbox."
        </div>
      </div>
    </section>
  );
};
