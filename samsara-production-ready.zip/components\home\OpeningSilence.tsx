'use client';
import React from 'react';
import { motion } from 'framer-motion';

export const OpeningSilence = () => {
  return (
    <section className="h-screen w-full flex items-center justify-center bg-stone-50 overflow-hidden relative">
      <div className="absolute inset-0 bg-[url('/noise.png')] opacity-20 pointer-events-none mix-blend-multiply"></div>
      
      {/* Ambient Background Circle */}
      <motion.div 
        className="absolute w-[800px] h-[800px] rounded-full bg-sage-100/30 blur-3xl"
        animate={{ scale: [1, 1.1, 1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="relative z-10 text-center space-y-8 px-6">
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.5, delay: 0.5 }}
          className="text-stone-500 uppercase tracking-[0.3em] text-sm"
        >
          Breathe. Arrive. Be.
        </motion.p>
        
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.5, delay: 1 }}
          className="font-serif text-5xl md:text-7xl lg:text-8xl text-stone-800 leading-tight"
        >
          Sanctuary for the<br />
          <span className="italic font-light">Modern Spirit</span>
        </motion.h1>
      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.5, duration: 1 }}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 text-stone-400 text-xs tracking-widest uppercase"
      >
        Scroll to Begin
      </motion.div>
    </section>
  );
};
