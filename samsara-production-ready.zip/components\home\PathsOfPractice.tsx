'use client';
import React from 'react';
import { motion } from 'framer-motion';

const paths = [
  { title: "Meditation", desc: "Cultivate inner silence." },
  { title: "Service", desc: "Action as prayer." },
  { title: "Learning", desc: "Wisdom from the source." },
  { title: "Healing", desc: "Restore balance." },
];

export const PathsOfPractice = () => {
  return (
    <section className="py-24 bg-stone-50">
      <div className="container-wide">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl text-stone-900 mb-4">Paths of Practice</h2>
          <p className="text-stone-500 max-w-xl mx-auto">There are many ways to the summit. Choose the path that resonates with your current season of life.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {paths.map((path, idx) => (
            <motion.div 
              key={idx}
              whileHover={{ y: -5 }}
              className="p-8 bg-white border border-stone-100 hover:border-sage-200 transition-colors shadow-sm hover:shadow-md cursor-pointer"
            >
              <h3 className="font-serif text-xl text-stone-800 mb-2">{path.title}</h3>
              <p className="text-sm text-stone-500">{path.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
