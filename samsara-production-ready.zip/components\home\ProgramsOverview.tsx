'use client';
import React from 'react';

const programs = [
  { title: "Silent Retreats", type: "Immersion", duration: "3-10 Days" },
  { title: "Mindfulness Teacher Training", type: "Certification", duration: "6 Months" },
  { title: "Weekend Reset", type: "Workshop", duration: "2 Days" },
];

export const ProgramsOverview = () => {
  return (
    <section className="py-24 bg-white">
      <div className="container-wide">
        <div className="flex justify-between items-end mb-16">
          <div>
            <h2 className="font-serif text-4xl text-stone-900 mb-2">Programs & Offerings</h2>
            <p className="text-stone-500">Structured paths for deep transformation.</p>
          </div>
          <a href="/programs" className="hidden md:block text-stone-900 border-b border-stone-300 pb-1 hover:border-stone-900 transition-colors text-sm">
            View All Programs
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {programs.map((prog, idx) => (
            <div key={idx} className="group cursor-pointer">
              <div className="h-64 bg-stone-100 mb-6 group-hover:bg-stone-200 transition-colors relative overflow-hidden">
                <div className="absolute top-4 left-4 bg-white/90 px-3 py-1 text-xs uppercase tracking-wider">{prog.type}</div>
              </div>
              <h3 className="font-serif text-xl text-stone-900 mb-1 group-hover:text-sage-700 transition-colors">{prog.title}</h3>
              <p className="text-stone-500 text-sm">{prog.duration}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
