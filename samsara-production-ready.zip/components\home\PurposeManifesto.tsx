'use client';
import React from 'react';
import { motion } from 'framer-motion';

export const PurposeManifesto = () => {
  return (
    <section className="py-32 px-6 bg-stone-100 relative">
      <div className="container-wide max-w-4xl mx-auto text-center space-y-12">
        <motion.span 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="block text-sage-600 uppercase tracking-widest text-xs font-semibold"
        >
          Our Purpose
        </motion.span>
        
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="font-serif text-3xl md:text-5xl leading-relaxed text-stone-800"
        >
          We believe that true wellness is not a product, but a <span className="italic text-sage-700">return to self</span>. 
          Samsara exists to bridge the gap between ancient wisdom and modern living, 
          creating a world where spiritual growth is accessible, grounded, and deeply community-driven.
        </motion.h2>

        <div className="h-20 w-[1px] bg-stone-300 mx-auto mt-12"></div>
      </div>
    </section>
  );
};
