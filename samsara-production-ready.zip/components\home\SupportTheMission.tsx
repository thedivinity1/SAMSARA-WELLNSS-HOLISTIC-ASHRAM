'use client';
import React from 'react';

export const SupportTheMission = () => {
  return (
    <section className="py-32 bg-stone-900 text-stone-50 text-center">
      <div className="container-wide max-w-4xl mx-auto space-y-10">
        <span className="text-sage-300 uppercase tracking-widest text-xs">Dana (Generosity)</span>
        <h2 className="font-serif text-5xl md:text-6xl leading-tight">
          Help us keep wisdom free for those who cannot pay.
        </h2>
        <p className="text-stone-400 max-w-2xl mx-auto text-lg">
          Samsara is 100% donor-funded. Your contribution directly supports scholarships, 
          ashram maintenance, and free digital resources.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto pt-8">
          <button className="py-6 border border-stone-700 hover:bg-stone-800 transition-colors">
            <span className="block text-2xl font-serif mb-1">$50</span>
            <span className="text-xs text-stone-500 uppercase">One Time</span>
          </button>
          <button className="py-6 border border-sage-600 bg-sage-900/50 hover:bg-sage-900 transition-colors relative overflow-hidden">
             <div className="absolute top-0 right-0 bg-sage-600 text-white text-[10px] px-2 py-1">MOST COMMON</div>
            <span className="block text-2xl font-serif mb-1">$25</span>
            <span className="text-xs text-stone-500 uppercase">Monthly</span>
          </button>
          <button className="py-6 border border-stone-700 hover:bg-stone-800 transition-colors">
            <span className="block text-2xl font-serif mb-1">Custom</span>
            <span className="text-xs text-stone-500 uppercase">Amount</span>
          </button>
        </div>
      </div>
    </section>
  );
};
