'use client';
import React from 'react';
import { motion } from 'framer-motion';

export const TheAshramExperience = () => {
  return (
    <section className="py-24 bg-stone-900 text-stone-50 overflow-hidden relative">
      <div className="absolute inset-0 opacity-10 bg-[url('/ashram-texture.png')] mix-blend-overlay"></div>
      
      <div className="container-wide relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div className="space-y-8">
          <span className="text-sage-300 uppercase tracking-widest text-xs">The Physical Sanctuary</span>
          <h2 className="font-serif text-4xl md:text-5xl leading-tight">
            A rhythm of life aligned with nature.
          </h2>
          <p className="text-stone-400 leading-relaxed max-w-md">
            Waking with the sun. Silent meals. Community work. Deep inquiry. 
            The Ashram is not a retreat center; it is a school for the soul.
          </p>
          <button className="px-8 py-3 border border-stone-700 hover:bg-stone-800 transition-colors text-sm tracking-wider">
            Explore Daily Life
          </button>
        </div>
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="h-[500px] bg-stone-800 rounded-sm flex items-center justify-center text-stone-600"
        >
          [Video Loop: Morning Rituals]
        </motion.div>
      </div>
    </section>
  );
};
