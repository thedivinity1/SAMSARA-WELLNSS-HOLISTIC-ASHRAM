'use client';
import React from 'react';

export const TransparencyPromise = () => {
  return (
    <section className="py-24 bg-white">
      <div className="container-wide grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div className="space-y-6">
          <span className="text-sage-600 uppercase tracking-widest text-xs font-semibold">Radical Transparency</span>
          <h2 className="font-serif text-4xl text-stone-900">Trust is the foundation of service.</h2>
          <p className="text-stone-600 leading-relaxed">
            As a registered NGO, we believe you deserve to know exactly where every dollar goes. 
            We publish quarterly financial audits, impact reports, and governance minutes.
          </p>
          <div className="flex gap-4 pt-4">
            <button className="text-stone-900 border-b border-stone-300 hover:border-stone-900 pb-1 text-sm">View Annual Report</button>
            <button className="text-stone-900 border-b border-stone-300 hover:border-stone-900 pb-1 text-sm">Our Ethics Code</button>
          </div>
        </div>
        <div className="bg-stone-100 h-96 flex items-center justify-center text-stone-400 rounded-sm">
          [Interactive Impact Map Placeholder]
        </div>
      </div>
    </section>
  );
};
