'use client';
import React from 'react';

export const VolunteerWithUs = () => {
  return (
    <section className="py-24 bg-sage-50">
      <div className="container-wide text-center max-w-3xl mx-auto space-y-8">
        <h2 className="font-serif text-4xl text-stone-900">Service is the highest practice.</h2>
        <p className="text-stone-600 leading-relaxed">
          Whether you have 2 hours a week or 6 months to give, your skills can build this sanctuary. 
          We are currently looking for:
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          {['Permaculture Gardeners', 'Digital Archivists', 'Event Coordinators', 'Translation Guides'].map((role, idx) => (
            <span key={idx} className="bg-white px-4 py-2 rounded-full text-sm text-sage-800 border border-sage-100 shadow-sm">
              {role}
            </span>
          ))}
        </div>
        <div className="pt-8">
          <button className="bg-sage-700 text-white px-8 py-3 hover:bg-sage-800 transition-colors tracking-wide">
            Apply to Volunteer
          </button>
        </div>
      </div>
    </section>
  );
};
