'use client';
import React from 'react';
import { motion } from 'framer-motion';

export const WhatIsSamsara = () => {
  const features = [
    { title: "Registered NGO", description: "Ethical governance and transparent impact." },
    { title: "Living Ashram", description: "A physical sanctuary for deep immersion." },
    { title: "Digital Sanctuary", description: "Wisdom accessible from anywhere." },
    { title: "Global Community", description: "Connected by shared values and practice." }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="container-wide">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative h-[600px] bg-stone-200 rounded-sm overflow-hidden"
          >
            {/* Placeholder for Image */}
            <div className="absolute inset-0 flex items-center justify-center text-stone-400">
              [Ashram Image: Nature, Light, Silence]
            </div>
          </motion.div>

          <div className="space-y-12">
            <div className="space-y-6">
              <h2 className="font-serif text-4xl md:text-5xl text-stone-900">What is Samsara?</h2>
              <p className="text-stone-600 text-lg leading-relaxed">
                We are more than a platform. We are a living ecosystem designed to nurture the human spirit. 
                Unlike commercial wellness apps, our foundation is built on service, lineage, and community.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {features.map((feature, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="border-l border-sage-200 pl-6"
                >
                  <h3 className="font-serif text-xl text-stone-800 mb-2">{feature.title}</h3>
                  <p className="text-stone-500 text-sm">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
