import React from 'react';
import { Logo } from '@/components/ui/Logo';
import Link from 'next/link';

export const Footer = () => {
  return (
    <footer className="bg-stone-900 text-stone-400 py-20">
      <div className="container-wide grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="space-y-6">
          <Logo className="text-stone-50" />
          <p className="text-sm leading-relaxed max-w-xs">
            A registered NGO, living wellness ashram, and digital sanctuary. 
            Merging ancient wisdom with modern science for global transformation.
          </p>
        </div>

        <div>
          <h4 className="text-stone-50 font-serif text-lg mb-6">Explore</h4>
          <ul className="space-y-3 text-sm">
            <li><Link href="/about" className="hover:text-stone-200 transition-colors">About Samsara</Link></li>
            <li><Link href="/ashram" className="hover:text-stone-200 transition-colors">The Ashram</Link></li>
            <li><Link href="/programs" className="hover:text-stone-200 transition-colors">Programs & Paths</Link></li>
            <li><Link href="/journal" className="hover:text-stone-200 transition-colors">Journal</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-stone-50 font-serif text-lg mb-6">Community</h4>
          <ul className="space-y-3 text-sm">
            <li><Link href="/get-involved" className="hover:text-stone-200 transition-colors">Get Involved</Link></li>
            <li><Link href="/volunteer" className="hover:text-stone-200 transition-colors">Volunteer</Link></li>
            <li><Link href="/donate" className="hover:text-stone-200 transition-colors">Donate</Link></li>
            <li><Link href="/impact" className="hover:text-stone-200 transition-colors">Impact & Transparency</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-stone-50 font-serif text-lg mb-6">Stay Connected</h4>
          <p className="text-sm mb-4">Receive wisdom, not noise.</p>
          <form className="flex flex-col gap-3">
            <input 
              type="email" 
              placeholder="Your email address" 
              className="bg-stone-800 border border-stone-700 p-3 text-stone-200 focus:outline-none focus:border-stone-500 transition-colors text-sm"
            />
            <button type="submit" className="bg-stone-200 text-stone-900 py-3 text-sm tracking-wider hover:bg-white transition-colors">
              Subscribe
            </button>
          </form>
        </div>
      </div>
      <div className="container-wide mt-20 pt-8 border-t border-stone-800 flex flex-col md:flex-row justify-between items-center text-xs text-stone-500">
        <p>&copy; {new Date().getFullYear()} Samsara Wellness. All rights reserved.</p>
        <div className="flex gap-6 mt-4 md:mt-0">
          <Link href="/privacy" className="hover:text-stone-300">Privacy Policy</Link>
          <Link href="/terms" className="hover:text-stone-300">Terms of Service</Link>
          <Link href="/accessibility" className="hover:text-stone-300">Accessibility</Link>
        </div>
      </div>
    </footer>
  );
};
