'use client';
import Link from 'next/link';
import { Logo } from '@/components/ui/Logo';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
// import { Menu, X } from 'lucide-react'; 

const navLinks = [
  { name: 'About', href: '/about' },
  { name: 'The Ashram', href: '/ashram' },
  { name: 'Programs', href: '/programs' },
  { name: 'Practice', href: '/practice' },
  { name: 'Community', href: '/community' },
];

const secondaryLinks = [
  { name: 'Philosophy', href: '/philosophy' },
  { name: 'Lineage & Teachers', href: '/lineage' },
  { name: 'Daily Practices', href: '/daily-practices' },
  { name: 'Retreat Calendar', href: '/calendar' },
  { name: 'Volunteer Roles', href: '/volunteer' },
  { name: 'Research & Whitepapers', href: '/research' },
  { name: 'Annual Reports', href: '/reports' },
  { name: 'Ethics & Safeguarding', href: '/ethics' },
];

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-500 bg-stone-50/90 backdrop-blur-md border-b border-stone-100">
        <div className="container-wide h-20 flex items-center justify-between">
          <Logo />

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                href={link.href}
                className="text-stone-600 hover:text-stone-900 transition-colors text-sm uppercase tracking-widest"
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-6">
            <Link href="/donate" className="hidden md:block px-6 py-2 bg-stone-900 text-stone-50 text-sm tracking-wider hover:bg-stone-800 transition-colors">
              Donate
            </Link>
            <button 
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Menu" 
              className="p-2 text-stone-900 z-50 relative uppercase tracking-widest text-sm font-semibold"
            >
               {isOpen ? "CLOSE" : "MENU"}
            </button>
          </div>
        </div>
      </header>

      {/* Mega Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 bg-stone-50 pt-24 px-6 overflow-y-auto"
          >
            <div className="container-wide grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 py-12">
              <div className="space-y-6">
                <h3 className="font-serif text-2xl text-stone-400">Main</h3>
                <ul className="space-y-4">
                  {navLinks.map((link) => (
                    <li key={link.name}>
                      <Link 
                        href={link.href} 
                        onClick={() => setIsOpen(false)}
                        className="text-3xl font-serif text-stone-900 hover:text-sage-700 transition-colors"
                      >
                        {link.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-6">
                <h3 className="font-serif text-2xl text-stone-400">Explore</h3>
                <ul className="space-y-3">
                  {secondaryLinks.slice(0, 4).map((link) => (
                    <li key={link.name}>
                      <Link 
                        href={link.href} 
                        onClick={() => setIsOpen(false)}
                        className="text-stone-600 hover:text-stone-900 text-lg"
                      >
                        {link.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-6">
                <h3 className="font-serif text-2xl text-stone-400">Impact</h3>
                <ul className="space-y-3">
                  {secondaryLinks.slice(4).map((link) => (
                    <li key={link.name}>
                      <Link 
                        href={link.href} 
                        onClick={() => setIsOpen(false)}
                        className="text-stone-600 hover:text-stone-900 text-lg"
                      >
                        {link.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-8 bg-stone-100 p-8 rounded-sm">
                 <div>
                   <h3 className="font-serif text-2xl text-stone-900 mb-2">Visit the Ashram</h3>
                   <p className="text-stone-600 text-sm mb-4">
                     Open for day visitors: 9am - 5pm<br/>
                     Retreat check-in: Fridays 2pm
                   </p>
                   <Link href="/visit" className="text-sage-700 underline underline-offset-4 text-sm">Plan your visit</Link>
                 </div>
                 <div>
                   <h3 className="font-serif text-2xl text-stone-900 mb-2">Support Us</h3>
                   <p className="text-stone-600 text-sm mb-4">
                     Samsara is 100% non-profit.
                   </p>
                   <Link href="/donate" className="text-sage-700 underline underline-offset-4 text-sm">Make a donation</Link>
                 </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
